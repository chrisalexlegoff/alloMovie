import * as Axios from 'axios';


const apiFirebase = Axios.create({
    baseURL:'https://allomovie-4f45b-default-rtdb.europe-west1.firebasedatabase.app/'
})

export default apiFirebase;